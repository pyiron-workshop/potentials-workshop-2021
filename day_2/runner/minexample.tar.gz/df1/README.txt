From RuNNer to N2P2

1.Mode 1/runner_mode 1
    -you need input.data and input.nn
2.Mode 2/runner_mode 2
    -input.nn ->runner_mode keyword to 2
    -run the fit
3.Mode 3/runner_mode 3
    -for prediction only a few files are necessary:
        -input.nn ->runner_mode keyword to 3
        -rename the files optweights.*.out to weights.*.data
        -scaling.data if used durign fit
